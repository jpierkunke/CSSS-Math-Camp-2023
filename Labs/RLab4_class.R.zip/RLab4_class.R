# Day 4 lab, Thu 9/14/23
# Today we'll cover
# - Matrices in R
# - For-loops, vectorization, and code efficiency
# - Benchmarking (timing) your code
# - Writing your own functions
# Jess Kunke

# load packages at the top of the script
library(tidyverse)
# install.packages("tictoc")
library(tictoc)
library(rbenchmark)


#### Matrices in R ####

# here's how to make two simple matrices in R
A = matrix(c(1,2,3,4), nrow=2)
B = matrix(c(1,2,1,2), nrow=2)
C = matrix(c(6,5,4,3,2,1), nrow=2)

# take a look at them

# first, work out on paper what each of the following should give you:
# A+B
# AB (shorthand for A times B)
# AC
# CA
# A^T (transpose of A)
# A^(-1) (inverse of A)

# Then let's try some operations in R:
A+B
A*B
A %*% B
C %*% A
t(A) # transpose of A
solve(A) # inverse of A



#### For-loops ####

# let's try adding two matrices with a for-loop
# initializing a matrix
sumA.B = matrix(NA, nrow=2, ncol=2)
for(i in 1:2){
  for(j in 1:2){
    sumA.B[i,j] = A[i,j]+B[i,j]
    # print(A[i,j]+B[i,j])
  }
}


#### Benchmarking ####

##### Using tictoc #####
# so which is faster in R, A+B or the for-loop version?

tic("matrix")
sum1 = A+B
toc()

tic("for-loop")
sum2 = matrix(NA, nrow=2, ncol=2)
for(i in 1:2){
  for(j in 1:2){
    sum2[i,j] = A[i,j]+B[i,j]
  }
}
toc()

# notice the variability from one run to another
# ideally we would repeat this many times and compare 
#   the average times across the many runs

# we could write a for-loop to do that!
# if we just copy and paste the above code into a for-loop,
#  we will have to sift through all the output it prints
#  to find the times and compare them

for(iter in 1:1000){
  tic("matrix")
  sum1 = A+B
  toc()
  
  tic("for-loop")
  sum2 = matrix(NA, nrow=2, ncol=2)
  for(i in 1:2){
    for(j in 1:2){
      sum2[i,j] = A[i,j]+B[i,j]
    }
  }
  toc()
}


# it would be nicer if we could gather all the times
#    together in one place or take the average to facilitate
#    our comparison
# we can do this by hand or use a package like rbenchmark

##### rbenchmark and writing your own functions #####

# this function takes two matrices and returns their sum
matrix.sum = function(A, B){
  # do computation
  # return result
  return(A+B)
}

for.loop.sum = function(C,D){
  sumCD = matrix(NA, nrow=2, ncol=2)
  for(i in 1:2){
    for(j in 1:2){
      sumCD[i,j] = C[i,j]+D[i,j]
    }
  }
  return(sumCD)
}


benchmark(
  "matrix sum" = {
    matrix.sum(A,B)
  },
  "for-loop" = {
    for.loop.sum(A,B)
  },
  replications = 1000,
  columns = c("test", "replications", "elapsed",
              "relative", "user.self", "sys.self")
)


# How do you tell what to replace nested for-loops with?
# - analogy to linear vs nonlinear
# - ask yourself, can I express this in terms of rows and columns?
# - R (especially tidyverse) cheatsheets
# - googling the task you're trying to do and maybe also add the word vectorized




