# Day 3 lab, Wed 9/13/23
# more tidyverse!
# Jess Kunke, Erin Lipman

# load packages at the top of the script
library(tidyverse)

#### Script workflow example: Building a data preprocessing script ####

milk = read.csv("milk_day3.csv")

# take a look at the variable names and diet types...
# what three things do you notice? what should we do?

# first we'll explore the data and the changes we want to make
# then we'll write a separate script to read in the data and
#  make those changes
# that way we can just run that script start to finish anytime
#  in the future to clean/preprocess the data

# note: you can start a new line after a comma or +



#### Pivoting between wide and long format ####

# Recall Example 2 from yesterday:

# let’s compute the average protein level at each week for each diet
avg_protein = milk %>%
  group_by(Diet, Week) %>%
  summarize(avg_protein_value = mean(Protein))

# maybe a better format for the table we get in Example 2
#  would be a 19 x 3 table, where each row is a week, each 
#  column is a diet, and the values in the table are the average 
#  protein values for that week-diet combination:
#
# Week Barley Lupins Mixed
#  1     ...    ...   ...
#  2     ...    ...   ...
#  3     ...    ...   ...
#  4     ...    ...   ...
#  5     ...    ...   ...
# ...    ...    ...   ...
#
# For this, we want to turn this long-format table (every row is a 
#  week-diet combination, so the average protein values are all in one long 
#  column) into a wide-format table (we break that column into multiple 
#  columns according to what diet they’re from, making the table wider).
#  We’ll use the pivot_wider function from the tidyr package:

avg_protein_wide = avg_protein %>%
  # pivot_wider takes these arguments:
  # names_from=the variable to use for the names of the new columns in wide format,
  # values_from=the current variable/column whose values will be the values in those new columns
  pivot_wider(names_from=Diet, values_from=avg_protein_value)

# prints out the object avg_protein_wide
avg_protein_wide
print(avg_protein_wide)

# go back to long format
avg_protein_long = avg_protein_wide %>%
  # pivot_longer takes these arguments:
  # names_to = name of the variable to be created
  # values_to = name of the variable measured in each column that we're
  #  combining (this will be the name of the new long column we're making)
  # cols = a vector of columns
  # note that any variable not mentioned will be unchanged
  pivot_longer(cols = Barley:Mixed, names_to="Diet", values_to="avg_protein_value") %>%
  # optional: sort in order by certain columns
  # here this line is not necessary, but often this is useful
  arrange(Diet, Week) %>%
  relocate(Diet, .before=Week)

# did we get back the same data frame we started with?
identical(avg_protein, avg_protein_long)
sum(avg_protein != avg_protein_long)
all.equal(avg_protein, avg_protein_long, check.attributes=FALSE)

# looking up questions for R:
# - google
# - https://rseek.org/
# - ChatGPT


#### Your Turn ####

# 1. For how many weeks do we have observations for each cow?

# if you need to rerun these commands, uncomment them:
# library(tidyverse)
# milk = read.csv("milk.csv")

# one solution:
milk %>%
  count(Cow)

# another:
milk %>%
  group_by(Cow) %>%
  summarize(n.weeks = n())



# 2. How many observations do we have for each diet in each week?

# one solution:
milk %>%
  count(Diet)

# another:
milk %>%
  group_by(Diet) %>%
  summarize(n.weeks = n())



# 3. How many high-protein observations do we have for each diet in each week?

# one solution (there are others):
milk %>%
  filter(Protein>3.8) %>%
  count(Diet)


# 4. Come up with another question for yourself or your work partner!





#### Plotting with ggplot(2)! ####

# Let's plot the protein levels (y-axis) by week (x-axis) for each cow (one
# line per cow), and we can color code the lines based on the cow's diet.

ggplot(data=milk, aes(x=Week, y=Protein, group=Cow, color=Diet)) +
  geom_point() +
  geom_line() +
  ggtitle("Protein levels by week for each cow")

# Let's do this step by step to see what it's doing

# Notice that if you just plot the first line with the `ggplot()` command,
# it doesn't plot anything!  It just sets up the plotting area.

ggplot(data=milk, aes(x=Week, y=Protein, group=Cow, color=Diet))

ggplot(data=milk, aes(x=Week, y=Protein, group=Cow, color=Diet)) +
  geom_point()


ggplot(data=milk, aes(x=Week, y=Protein, group=Cow, color=Diet)) +
  # geom_point() +
  geom_line()

# What does ggtitle() do?
ggplot(data=milk, aes(x=Week, y=Protein, group=Cow, color=Diet)) +
  geom_point() +
  geom_line() +
  ggtitle("Protein levels by week for each cow")

##### Perhaps a nicer plot #####

# note: we can store the graph to an object and edit/save it later
milk_graph = ggplot(data=milk, aes(x=Week, y=Protein, group=Cow, color=Diet)) +
    geom_line(alpha=0.5) +
    ggtitle("Protein levels by week for each cow") +
    theme_bw() +
    scale_color_manual(values=c("mediumorchid4", "darkgoldenrod1", "deepskyblue"))

# to view the plot
milk_graph

# what do you think we need group=Cow for? try running the same code without it
# for more: https://ggplot2.tidyverse.org/reference/aes_group_order.html
ggplot(data=milk, aes(x=Week, y=Protein, color=Diet)) +
  geom_line(alpha=0.5) +
  ggtitle("Protein levels by week for each cow") +
  theme_bw() +
  scale_color_manual(values=c("mediumorchid4", "darkgoldenrod1", "deepskyblue"))




##### Using facet_wrap #####

# using facet_wrap
ggplot(data=milk, aes(x=Week, y=Protein, group=Cow, color=Diet)) +
  geom_line(alpha=0.5) +
  facet_wrap(~Diet) +
  ggtitle("Protein levels by week for each cow") +
  theme_minimal() +
  scale_color_manual(values=c("mediumorchid4", "darkgoldenrod1", "deepskyblue"))

# how can we remove the legend since it's redundant now?
# => how can we figure out how to do that?


# we'll see facet_grid in the practice section, but it's very similar to facet_wrap


# Further plot resources -------------------------------------------
# For more information on modifying colors, legends, etc.:
# http://www.cookbook-r.com/Graphs/index.html
# For specific R color names:
# http://www.stat.columbia.edu/~tzheng/files/Rcolor.pdf
# Shapes and linetypes can be modified in a similar way:
# http://www.cookbook-r.com/Graphs/Shapes_and_line_types
# See also https://colorbrewer2.org/

#### Your Turn ####

# 1. What does the following code do?
milk_graph +
  facet_grid(. ~ Diet)
# result should be just like our facet_wrap example above

# 2. What does the following code do? How is the result different from 
#    the previous question?
milk_graph +
  facet_grid(Diet ~ .)
# same, except now the three panels are stacked vertically instead of horizontally

# 3. What does the following code do?
milk_graph +
  facet_wrap( ~ Cow, ncol=10)
# shows a separate panel for each cow, and it wraps (new line) after every 10 cows
# try ncol=6 or ncol=2
# can you figure out how to pick just 10 of the cows to plot?

# 4. Let's plot the average protein level at each week for each diet.
#    This should give you a plot of average protein level versus week,
#    with just three lines (each a different color, just one line for 
#    each diet, since you've averaged over all the cows in each diet group).
# - to do this, do you want to use avg_protein_long or avg_protein_wide?

# we want the long format (avg_protein_long or avg_protein)
# one of many solutions:
ggplot(data=avg_protein_long, aes(x=Week, y=avg_protein_value, color=Diet)) +
  geom_line(alpha=0.5) +
  ggtitle("Average weekly protein level and diet") +
  theme_minimal() +
  scale_color_manual(values=c("mediumorchid4", "darkgoldenrod1", "deepskyblue")) +
  ylab("Average protein value")
# questions for you to think about:
# - why don't we need or want "group=Cow" anymore?

# 6. Try changing some of your plot settings: for example, you might plot
#    just lines, just points, or both; change the theme; or find out how to
#    change the axis labels.



