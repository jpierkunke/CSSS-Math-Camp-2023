# Day 5 lab, Fri 9/15/23
# Today we'll cover
# - Generating random numbers according to a distribution
# - Applications (benchmarking, simulations)
# - R Markdown
# Jess Kunke, Erin Lipman

# load packages at the top of the script
library(tidyverse)
library(tictoc)
library(rbenchmark)


#### Solving problems with simulations ####

# Suppose that there are 30 people enrolled in Math Camp.
# How likely do you think it is that there are two people in the group
# who share the same birthday?

# While it is possible to answer this question using probability calculations, 
# we can answer this question using simulation in R.

# We can solve the birthday problem in the following way:

# 1. Simulate a class of 30 people by sampling a random birthday out of the
#    365 days of the year.
# 2. Check whether or not any two people share the same birthday.
# 3. Repeat this experiment a large number of times and calculate the
#    proportion of trials for which two people share a birthday.

# first, let's try out the sample function:
?sample
# run this line a few times
sample(1:20, 10)
# then run this line a few times
sample(1:20, 10, replace = TRUE)

# Step one: draw random birthdays for 30 people
# how can we use sample to do that?
# - what's the x vector you're sampling from?
# - what is the size of the sample you want to draw?
# - do you want replace = TRUE or FALSE?
class.bdays = sample(1:365, 30, replace = TRUE)

# Step 2
table(class.bdays)
# how can we use the above results to create a variable called is_repeated
#  that equals 1 if at least two people have the same birthday (i.e. at least
#  one birthday appears more than once among the 30 people),
#  and equals 0 otherwise?

# here are four different solutions we came up with!

is_repeated = ifelse(sum(duplicated(class.bdays))==0, 0, 1)

is_repeated = ifelse(length(unique(class.bdays))==30, 0, 1)

is_repeated = as.numeric(sum(table(class.bdays)>1)>0)

is_repeated = sum(table(class.bdays))>length(table(class.bdays))

# Step 3
# as a start, try this manually a few times; simulate 2-3 different classes
# and determine whether is_repeated = 0 or 1 for each class

# next we'll scale this up to get a better estimate of the probability.
# R allows us to write our own functions, which is useful when we want to 
# repeat something many times. Let's adapt our code from the two chunks 
# above into a function that simulates a class and returns 0 or 1
# depending on whether or not at least two people share the same birthday.

# write your function here! call it simulate.class.bdays

simulate.class.bdays = function(){
  class.bdays = sample(1:365, 30, replace = TRUE)
  is_repeated = ifelse(sum(duplicated(class.bdays))==0, 0, 1)
  is_repeated
}

# if you want to be able to change the size, use this version
# - note: what changes will you have to make to lines 95 and 103 below?
# simulate.class.bdays = function(n.grp){
#   class.bdays = sample(1:365, n.grp, replace = TRUE)
#   is_repeated = ifelse(sum(duplicated(class.bdays))==0, 0, 1)
#   is_repeated
# }



# run it a few times to test how it works



# use map_dbl (a vectorized purrr function) to run 10,000 simulations
classes_all = map_dbl(1:10000, ~simulate.class.bdays())

# the mean of the 0s and 1s gives you your estimate of the proportion of the
# time that you get a 1 (i.e. the proportion of time that you expect to find
# at least 1 birthday shared by at least 2 people)
mean(classes_all)

# try repeating the last two lines a few times:
classes_all = map_dbl(1:10000, ~simulate.class.bdays())
mean(classes_all)
# what do you notice?



# More about the birthday problem:
# https://en.wikipedia.org/wiki/Birthday_problem




#### Sampling from distributions / generating random samples ####

# let's run this a few times and change some of the parameters
?rbinom
rbinom(10, 100, 0.5)

samples = rbinom(1000, 100, .5)
# mean: does this match the expected number of heads? should it?
mean(samples)
# variance: does this match the expected variance in the number of heads? should it?
var(samples)
# note: wikipedia pages on distributions are GREAT references
# e.g. https://en.wikipedia.org/wiki/Binomial_distribution


#### Your Turn ####

# run this chunk of code a few times and then try the questions after it
n_samples = 1000
n = 100
p = 0.5
samples = rbinom(n_samples, n, p)
hist(samples, breaks=min(samples):max(samples))

# 0. Compare the result of the last line of code above to hist(samples). 
#    What does the argument breaks do?

# 1. Why does the bar plot change slightly when you rerun the same code?

# 2. What function that is a property of the binomial distribution does this
#    histogram approximate: the pmf, the pdf, or the cdf?  

# 3. Try changing the number of samples and notice how the bar plot changes.

# 4. Try playing around with the values of n and p. How do the center, 
#    spread, and shape of the distribution change? Can you find an n and p
#    where the distribution looks more “lopsided” rather than symmetric?



#### A little more about distributions ####

grid <- seq(35, 65, 1) # vector of values 35, 36, ..., 65
pmf <- dbinom(grid, n, p) # calculates value of pmf for each grid value
samples = rbinom(n_samples, n, p)
hist(samples, prob=TRUE)
lines(grid, pmf)







#### Benchmarking least squares estimation methods ####
# We can also use benchmarking to compare the efficiency of computing the
# least squares estimate coefficients using lm() versus matrix operations

benchmark(
  "lm" = {
    X = matrix(rnorm(1000), 100, 10)
    y = X %*% sample(1:10, 10) + rnorm(100)
    b = lm(y ~ X + 0)$coef
  },
  "matrix operations" = {
    X = matrix(rnorm(1000), 100, 10)
    y = X %*% sample(1:10, 10) + rnorm(100)
    b = solve(t(X) %*% X) %*% t(X) %*% y
  },
  replications = 1000,
  columns = c("test", "replications", "elapsed", "relative") 
)


#### Another benchmarking package: microbenchmark ####

# for example, with simpler functions:
# generate 100 random numbers between 0 and 1 
x = runif(100)
# run benchmarking to compare sqrt() and x^0.5
microbenchmark(
  sqrt(x),
  x ^ 0.5
)
# note: what happens if you replace runif above with rnorm? why?


