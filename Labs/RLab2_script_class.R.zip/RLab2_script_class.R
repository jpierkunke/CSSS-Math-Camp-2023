# Day 2 lab <== add a title and a description to the top of your scripts, as well as possibly a name and date
# getting started in tidyverse at CSSS Math Camp 2023!
# Jess Kunke, Erin Lipman

# load packages at the top of the script
library(tidyverse)

# note: having 4 or more #'s start and finish makes a comment into a section header!

#### Read in the data ####
# note: you may need to change the input to this function to reflect
#   where your file is on your computer
milk <- read_csv("Documents/UW/UW_Year3_Q3_Spring2023/CSSS-math-camp-2023-coinstructor/materials/PM-R-Labs/milk.csv")
# note: you might like to check out setwd() and getwd(); ?setwd

# Please add comments to yourself in this script as we go through it!

#### Explore the data ####

str(milk)
head(milk) # what command do you think would show you the LAST 6 rows?
names(milk)
dim(milk)
ncol(milk)

##### Some base-R commands #####

# we'll mostly stick to tidyverse, but it's good to know some base-R too!

# how many different diets are there?
unique(milk$Diet)
# how many different weeks are represented in the data set?
unique(milk$Week)
range(milk$Week)
length(milk$Week)

# first argument = x axis
plot(milk$Week, milk$Protein)

boxplot(milk$Protein~milk$Diet)


#### Data manipulation with tidyverse! ####

##### filtering vs selecting ##### 

filter(milk, Diet=="Barley") # why doesn't this work? fix this line of code
filter(milk, Diet=="Barley" & Cow==1)
milk56 = filter(milk, Cow>4 & Cow<7)

select(milk, Diet)
select(milk, Diet:Cow) # range of variables (columns)
select(milk, Diet, Protein) # specific variables/columns

##### adding or changing columns ##### 

mutate(milk, HighProtein = (Protein>3.8))
# how do we change the above line of code so that it stores the result somewhere?
# let's talk a moment about logical statements/comparisons like Protein>3.8

##### combining steps: the joy of pipes ##### 

# Example 1
# how would we combine the above commands to add the HighProtein column,
#  then filter the data set for observations with HighProtein,
#  then select all columns except HighProtein,
#  and store the results as a new data frame called milk.hp?

# option 1
milk.hp = mutate(milk, HighProtein = (Protein>3.8))
milk.hp = filter(milk.hp, HighProtein==TRUE)
milk.hp = select(milk.hp, -HighProtein)

# option 2 (I've given it a different name just so we can compare them)
milk.hp2 = select(filter(mutate(milk, HighProtein = (Protein>3.8)), HighProtein==TRUE), -HighProtein)

sum(milk.hp != milk.hp2)
identical(milk.hp, milk.hp2) #same as above

# Let's try this with pipes instead.
# First let's see how a pipe works by rewriting the filter command above
filter(milk, Diet=="Barley")

# use shift-control-M or shift-command-M to make the pipe symbol %>%
milk %>% filter(Diet=="Barley")
# ?filter

# redoing Example 1 with pipes (we'll fill this in together)
milk.hp = milk %>% 
  # add a column HighProtein
  mutate(HighProtein = (Protein>3.8)) %>%
  # here I subset the data to the rows with high protein
  filter(HighProtein==TRUE) %>% 
  # drop the HighProtein column
  select(-HighProtein) 

##### group_by and summarize #####

# how many observations do we have per diet? is it fairly balanced?
# reminder: to toggle back and forth between commented and uncommented,
#  use shift-control-C or shift-command-C
n_obs_by_diet <- milk %>%
# milk %>%
  group_by(Diet) %>%
  summarize(n.obs = n())

# we can summarize with multiple outputs too, e.g.
# what is the average protein value for each diet?
milk %>%
  group_by(Diet) %>%
  summarize(NumOfObs = n(),
            mean.Protein = mean(Protein))

# you can group by more than one variable. for example,
# Example 2
# let’s compute the average protein level at each week for each diet
avg_protein <- milk %>%
  group_by(Diet, Week) %>%
  summarize(avg_protein_value = mean(Protein))

# what is different if you swap Week and Diet?
avg_protein <- milk %>%
  group_by(Week, Diet) %>%
  summarize(avg_protein_value = mean(Protein))

# we will improve on Example 2 in a moment, but first...

##### Your Turn #####

# How many different diets does each cow have? Do they each have a 
# different diet, or do some have different diets in different weeks?

cow.diet = milk %>% 
  group_by(Cow, Diet) %>% 
  summarize(n.week = n())

cow.diet2 = milk %>%
  count(Cow, Diet)

cow.diet3 = milk %>% 
  group_by(Cow) %>% 
  summarize(n.diets = length(unique(Diet)))

cow.diet4 = milk %>% 
  group_by(Cow) %>% 
  summarize(n.diets = n_distinct(Diet))

# Come up with another question you'd like to ask, either about this data set
#  or the midwest data set, and write some code to answer it

# - NOTE: we stopped here on Day 2; we'll pick up below on Day 3

##### Pivoting between wide and long format #####

# maybe a better format for the table we get in Example 2
#  would be a 19 x 3 table, where each row is a week, each 
#  column is a diet, and the values in the table are the average 
#  protein values for that week-diet combination:
#
# Week Barley Lupins Mixed
#  1     ...    ...   ...
#  2     ...    ...   ...
#  3     ...    ...   ...
#  4     ...    ...   ...
#  5     ...    ...   ...
# ...    ...    ...   ...
#
# For this, we want to turn this long-format table (every row is a 
#  week-diet combination, so the average protein values are all in one long 
#  column) into a wide-format table (we break that column into multiple 
#  columns according to what diet they’re from, making the table wider).
#  We’ll use the pivot_wider function from the tidyr package:

avg_protein_wide <- avg_protein %>%
  # pivot_wider takes these arguments:
  # names_from=the variable to use for the names of the new columns in wide format,
  # values_from=the current variable/column whose values will be the values in those new columns
  pivot_wider(names_from=Diet, values_from=avg_protein_value)

avg_protein_wide

# go back to long format
avg_protein_long <- avg_protein_wide %>%
  # pivot_longer takes these arguments:
  # names_to = name of the variable to be created
  # values_to = name of the variable measured in each column that we're
  #  combining (this will be the name of the new long column we're making)
  # cols = a vector of columns
  # note that any variable not mentioned will be unchanged
  pivot_longer(cols = Barley:Mixed, names_to="Diet", values_to="avg_protein_value") %>%
  # optional: sort in order by certain columns
  # here this line is not necessary, but often this is useful
  arrange(Diet, Week)

head(avg_protein_long)


##### Your Turn #####

# 1. For how many weeks do we have observations for each cow?


# 2. How many observations do we have for each diet in each week?


# 3. How many high-protein observations do we have for each diet in each week?


# 4. Come up with another question for yourself or your work partner!






